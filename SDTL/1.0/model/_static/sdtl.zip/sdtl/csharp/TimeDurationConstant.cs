using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace sdtl
{
    /// <summary>
    /// A time duration constant expressed in ISO 8601 format.
    /// 
    /// <summary>
    public partial class TimeDurationConstant : ExpressionBase
    {
        /// <summary>
        /// A duration of time in ISO 8601 format
        /// <summary>
        [JsonConverter(typeof(DurationConverter))]
        public TimeSpan TimeDurationValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ExpressionBase").Descendants())
            {
                xEl.Add(el);
            }
            if (TimeDurationValue != default(TimeSpan))
            {
                xEl.Add(new XElement(ns + "TimeDurationValue", string.Format("P{00}DT{00}H{00}M{00}S", 
                    TimeDurationValue.ToString("%d"), TimeDurationValue.ToString("%h"), TimeDurationValue.ToString("%m"), TimeDurationValue.ToString("%s"))));
            }
            return xEl;
        }
    }
}

