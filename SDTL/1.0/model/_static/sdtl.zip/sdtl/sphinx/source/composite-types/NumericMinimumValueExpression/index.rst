NumericMinimumValueExpression
-----------------------------

Represents the smallest numeric value supported by a system.


Properties
~~~~~~~~~~

This type contains no properties.

Properties Inherited from ExpressionBase
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

No properties are inherited.


Item Type Hierarchy
~~~~~~~~~~~~~~~~~~~

* :doc:`/composite-types/ExpressionBase/index`
    * **NumericMinimumValueExpression**


Relationships
~~~~~~~~~~~~~


.. container:: image

   |stub|

.. |stub| image:: ../../images/NumericMinimumValueExpression.svg

