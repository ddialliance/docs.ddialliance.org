StringConstantExpression
------------------------

A text string.


Properties
~~~~~~~~~~

.. csv-table::
   :header: "Name","Type","","Description"
   :widths: 15,10,5,100

   "Value","string","1..1","A string"

Properties Inherited from ExpressionBase
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

No properties are inherited.


Item Type Hierarchy
~~~~~~~~~~~~~~~~~~~

* :doc:`/composite-types/ExpressionBase/index`
    * **StringConstantExpression**


Relationships
~~~~~~~~~~~~~


.. container:: image

   |stub|

.. |stub| image:: ../../images/StringConstantExpression.svg

