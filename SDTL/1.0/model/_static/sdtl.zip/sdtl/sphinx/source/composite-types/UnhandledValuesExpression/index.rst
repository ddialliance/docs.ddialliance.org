UnhandledValuesExpression
-------------------------

Represents any values not previously handled (for example, in a set of recode rules).


Properties
~~~~~~~~~~

This type contains no properties.

Properties Inherited from ExpressionBase
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

No properties are inherited.


Item Type Hierarchy
~~~~~~~~~~~~~~~~~~~

* :doc:`/composite-types/ExpressionBase/index`
    * **UnhandledValuesExpression**


Relationships
~~~~~~~~~~~~~


.. container:: image

   |stub|

.. |stub| image:: ../../images/UnhandledValuesExpression.svg

